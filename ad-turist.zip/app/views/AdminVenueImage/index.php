<?php include 'app/views/_global/beforeContent.php'; ?>

<article class="row">
    <div class="col-xs-12">
        
    </div>
</article>

<?php include 'app/views/_global/afterContent.php'; ?>