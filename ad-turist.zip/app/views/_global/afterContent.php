            </section>
            <footer class="row">
                <p>&nbsp;</p>
                <p class="col-xs-12">
                    &copy; <?php echo date('Y'); ?> - AD-Turist
                </p>
            </footer>
        </div>
        
        <script src="<?php Configuration::BASE_URL; ?>assets/js/bootstrap.min.js"></script>
    </body>
</html>
