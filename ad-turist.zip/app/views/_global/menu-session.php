<ul class="nav nav-tabs">
    <li><a href="<?php echo Misc::link(''); ?>"><i class="glyphicon glyphicon-home"></i> Početna</a>
    <li><a href='<?php echo Misc::link('admin/locations') ?>'><i class="glyphicon glyphicon-road"></i> Locations</a></li>
    <li><a href='<?php echo Misc::link('admin/categories') ?>'><i class="glyphicon glyphicon-cd"></i> Venue Categories</a></li>
    <li><a href='<?php echo Misc::link('admin/tags') ?>'><i class="glyphicon glyphicon-fullscreen"></i> Tags</a></li>
    <li><a href='<?php echo Misc::link('admin/venues') ?>'><i class="glyphicon glyphicon-magnet"></i> Venues</a></li>
    <li><a href="<?php echo Misc::link('logout'); ?>"><i class="glyphicon glyphicon-log-out"></i> Odjava</a>
</ul>
