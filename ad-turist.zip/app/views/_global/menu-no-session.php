<ul class="nav nav-tabs">
    <li><a href="<?php echo Misc::link(''); ?>"><i class="glyphicon glyphicon-home"></i> Početna</a></li>
    <li><a href="<?php echo Misc::link('login'); ?>"><i class="glyphicon glyphicon-log-in"></i> Prijava</a></li>
</ul>
